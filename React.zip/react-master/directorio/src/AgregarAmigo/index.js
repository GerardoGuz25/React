import React from "react";

function AgregarAmigo(params){
    return(
        <button>+Amigo</button>
    )
}


export default AgregarAmigo;
